//
// Created by Derek Lin on 10/30/19.
//

#ifndef ROCKPAPERSCISSORS_GETAI_H
#define ROCKPAPERSCISSORS_GETAI_H

#include  <random>
#define ROCK 0
#define PAPER 1
#define SCISSORS 2
#pragma once
#include <iostream>
#include <cctype>
#include <string>
#include <time.h>
#include <stdlib.h>
#include <random>

using namespace std;
int getAIInput(minstd_rand &);



#endif //ROCKPAPERSCISSORS_GETAI_H
