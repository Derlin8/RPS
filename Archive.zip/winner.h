//
// Created by Derek Lin on 10/30/19.
//

#ifndef ROCKPAPERSCISSORS_WINNER_H
#define ROCKPAPERSCISSORS_WINNER_H
#pragma once
#include <iostream>
#include <cctype>
#include <string>
#include <time.h>
#include <stdlib.h>
#include <random>
#define ROCK 0
#define PAPER 1
#define SCISSORS 2
int winner(int, int);


#endif //ROCKPAPERSCISSORS_WINNER_H
